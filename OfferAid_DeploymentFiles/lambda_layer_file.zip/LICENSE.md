Copyright (c) 2019-2021, Innova Montreal Inc.
All rights reserved.

I. SOFTWARE LICENSE AGREEMENT

1. Definitions.
   
   "License" shall mean the terms and conditions for use as defined by 
   Sections 1 through 9 of this document.

   "Licensor" shall mean the copyright owner or entity authorized by
   the copyright owner that is granting the License.

   "Legal Entity" shall mean the union of the acting entity and all
   other entities that control, are controlled by, or are under common
   control with that entity. For the purposes of this definition,
   "control" means (i) the power, direct or indirect, to cause the
   direction or management of such entity, whether by contract or
   otherwise, or (ii) ownership of fifty percent (50%) or more of the
   outstanding shares, or (iii) beneficial ownership of such entity.

   "You" (or "Your") shall mean an individual or Legal Entity
   exercising permissions granted by this License.

   "Package" shall mean the .zip file archive distributed by Licensor.

2. Package content.

   This Package may includes a number of libraries with their own LICENSE 
   and TERMS OF USE, that you must accept and comply with as well. 
   Here is the list of libraries that may be included:

   - python/lib/python3.8/site-packages/scipy/LICENSE.txt
   - python/lib/python3.8/site-packages/scipy/LICENSES_bundled.txt
   - python/lib/python3.8/site-packages/numpy/LICENSES.txt
   - python/lib/python3.8/site-packages/pandas/LICENSE
   - python/lib/python3.8/site-packages/sklearn/COPYING
   - python/lib/python3.8/site-packages/xgboost/LICENSE

3. Copyright
   
   Although must of the libraries includes in this Package permit it 
   distribution under their own terms, this Package itself have been
   engineered and tested by the Licensor within a propietary procedure, 
   therefor, the Licensor retains all the rights of the resulting work 
   (this Package).

4. Limitation of use.

   You shall use this Package within the limits of the number of "AWS Lambdas"
   that you selected within your order, and you have paid for.
   For example, you may have pay for using this Package in comply
   with one of the following options:
   
   - Only within 1 Lambda
   - Until 5 Lambdas
   - Until 10 Lambdas
   - Until 20 Lambdas
   - Unlimited number of Lambdas

5. Distribution.

   Distribution of this Package is not permitted without written authorisation
   of the Licensor.

6. Disclaimer of Warranty. 
   
   Unless required by applicable law or
   agreed to in writing, Licensor provides this Package on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or
   implied, including, without limitation, any warranties or conditions
   of TITLE, NON-INFRINGEMENT, MERCHANTABILITY, or FITNESS FOR A
   PARTICULAR PURPOSE. You are solely responsible for determining the
   appropriateness of using this Package and assume any risks associated 
   with Your exercise of permissions under this License.

7. Limitation of Liability. 
   
   In no event and under no legal theory,
   whether in tort (including negligence), contract, or otherwise,
   unless required by applicable law (such as deliberate and grossly
   negligent acts) or agreed to in writing, shall the Licensor be
   liable to You for damages, including any direct, indirect, special,
   incidental, or consequential damages of any character arising as a
   result of this License or out of the use or inability to use this
   Package (including but not limited to damages for loss of goodwill,
   work stoppage, computer failure or malfunction, or any and all
   other commercial damages or losses).


THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
